#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Miguel Rovira-Gonzslez
# Date:  February 11th, 2019
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   <Miguel Rovira-Gonzalez>, February 11th, 2019, Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#input()

# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# Step 1
# Create a txt file named ToDo.txt
#-------------------------------------------------#
"""
objFileCreation = open("C:\\Users\\roviram\\_PythonClass\\Assignment05\\ToDo.txt", "w")
objFileCreation.write("Clean House, Low\n")
objFileCreation.write("Pay Bills, High\n")
objFileCreation.close()
"""

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------


# Step 1 - Load data from a file
    # When the program starts, load each "row" of data 
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"


objFile = open("C:\\Users\\roviram\\_PythonClass\\Assignment05\\Todo.txt", "r")
listTable = []
intChoice1 = 0
intChoice2 = 0
# Spitting the row from the file into a comma separated value and then loading it into a dictionary object
for element in objFile:
    strData = element.split(",")
    # print(strData)
    dictRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
    # print(dictRow)
    listTable.append(dictRow)

print(listTable)
# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print("-----------------------------------------------------------------------------------------------------------------")
        for element in listTable:
            intChoice1 += 1
            print(str(intChoice1) + ".", "What task needs to be completed?", element["Task"] + ".", "Cool, what is the priority of this task?", element["Priority"] + ".")
        intChoice1 = 0
        print("-----------------------------------------------------------------------------------------------------------------")
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        strTask = input("What chore needs to get done? ").strip()
        strPriority = input("Chores are no fun but that is part of life. What is the priority of " + strTask + "? [High | Low] ").strip()
        dictRow = {"Task": strTask.strip(), "Priority": strPriority.strip()}
        listTable.append(dictRow)
        print("Here is the updated chores table")
        for task in listTable:
            intChoice2 += 1
            print(str(intChoice2) + ".", task)
        intChoice2 = 0
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice.strip() == '3'):
        while (True):
            print("Time to remove some chores, this is the best choice!")
            for dic in listTable:
                print(str(dic) + "\n")
            strTask = input("Please enter a task to remove: ")
            strPriority = input("Please enter the priority of the task that needs to get removed [High | Low]: ")
            dictRow = {"Task": strTask.strip(), "Priority": strPriority.strip()}
            if (dictRow not in listTable):
                print("\nThat task does not exist. Please try again \n")
                continue

            elif (dictRow in listTable):
                listTable.remove(dictRow)
                print("Task has been removed!")
                break

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice.strip() == '4'):
        objFile = open("C:\\Users\\roviram\\_PythonClass\\Assignment05\\ToDo.txt", "a")
        print("Okay, it's time to save data in our ToDo text file")
        for dictionary in listTable:
            objFile.write(dictionary["Task"] + ", " + dictionary["Priority"] + "\n")
        print("The data has been saved to the file!")
        objFile.close()

    elif (strChoice.strip() == '5'):
        print("Goodbye!")
        break #and Exit the program

