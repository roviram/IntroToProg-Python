#-------------------------------------------------#
# Title: Assignment06
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   Miguel Rovira-Gonzalez, 02/18/2019, Updated Script to Organize Code in Classes and Functions
#   Miguel Rovira-Gonzalez, 02/18/2019, Made Sure the Menu Options Showed the Option 5 to the user so they could quit the program
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the file called errands "ToDo

# Step 7
# Exit program
#-------------------------------1

#----------------------------------------------------------------------------------------------#
# DATA SECTION
objFileName = "C:\\Users\\roviram\\_PythonClass\\Assignment06\\ToDo.txt"
strData = ""
dicRow = {}
lstTable = []
# DATA SECTION END
#----------------------------------------------------------------------------------------------#


#----------------------------------------------------------------------------------------------#
# PROCESSING SECTION START

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo txt into a python Dictionary
# Loading the data from the text file into a table

objFile = open(objFileName, "r")
for line in objFile:
    strData = line.split(",")  # readline() reads a line of the data into 2 elements
    dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
    lstTable.append(dicRow)
objFile.close()

"""
Create functions that do what the list of menu displays to the user
Menu of Options
1) Show current data
2) Add a new item.
3) Remove an existing item.
4) Save Data to File
5) Exit Program
"""

class to_do(object):
    #Displaying the Menu of Options to the User
    @staticmethod
    def menu_user_input():
        """This function is used to display the menu options to the user"""
        print("""
           Menu of Options
           1) Show current data
           2) Add a new item.
           3) Remove an existing item.
           4) Save Data to File
           5) Exit Program
           """)
        user_input = input("Which option would you like to perform? [1 to 5] - ")
        return user_input

    # 1) Showing Current Data to the User
    @staticmethod
    def current_data():
        """This function is used to show the current items in the To DO List"""
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    # 2) Adding a new Item
    @staticmethod
    def add_data():
        """This function is used to allow the user to add data to the To Do List"""
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
        print("Current Data in table:")
        for dicRow in lstTable:
            print(dicRow)

        # Show the User the Current Items
        to_do.current_data()

    # 3 Removing Data
    @staticmethod
    def remove_data():
        """This function removes data from the To Do List"""
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

        # 5c Show the current items in the table
        to_do.current_data()
        # Show the User the Current Data

    # 4) Saving Data to a File
    @staticmethod
    def save_data():
        """This function saves data into the To Do List"""
        # 5a Show the current items in the table
        to_do.current_data()
        # 5b Ask if they want save that data
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")

# PROCESSING SECTION END
#----------------------------------------------------------------------------------------------------------------#

# PRESENTATION SECTION START
#----------------------------------------------------------------------------------------------------------------#
"""
1) Show current data
2) Add a new item.
3) Remove an existing item.
4) Save Data to File
5) Exit Program
"""
while (True):
    # Creating Loop and conditional statements with defined functions
    # Always calling the menu user input function until the loop equals False.  Saving the result of the input to the strData
    strData = to_do.menu_user_input()
    # Show Current To DO Items
    if (strData == "1"):
        to_do.current_data()

    # Adding Data
    elif (strData == "2"):
        to_do.add_data()

    # Removing Data
    elif (strData == "3"):
        to_do.remove_data()

    # Saving Data
    elif (strData == "4"):
        to_do.save_data()

    # Quitting the program
    elif (strData == "5"):
        break
# PRESENTATION SECTION END
#----------------------------------------------------------------------------------------------------------------#






